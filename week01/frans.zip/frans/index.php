<?php
include 'data.php';
if(isset($_POST['vervoeging'])) {
    $vervoeging = $_POST['vervoeging'];
    $werkwoord = $_POST['werkwoord'];
    $persoon = $_POST['persoon'];
    $correct = $werkwoorden[$werkwoord][$persoon];

    if($vervoeging == $correct) {
        $feedback = "<div class='info correct'>Juist</div>";
    }
    else {
        $feedback = "<div class='info fout'>Fout: $persoon ($werkwoord) => $persoon $correct</div>";
    }
}
$total = count($werkwoorden);
$ww_keys = array_keys($werkwoorden);
$next = $ww_keys[rand(0,$total-1)];
$next_persoon = $personen[rand(0, 7)];

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frans voor Tergroenepoorte</title>
    <style>
        body { font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-weight: 300; display: flex; justify-content: center; align-items: center; height: 100vh; }
        form { font-size: 2rem; max-width: 800px; margin: 0 auto; }
        .info { padding: 8px 12px; border-radius: 3px; margin-bottom: 20px;}
        .info.correct { background: hsla(120, 100%, 50%, .3)}
        .info.fout { background: hsla(0, 100%, 50%, .3)}
        input { font-size: 2rem;}
    </style>
</head>
<body>
<form method='post'>
    <?= $feedback; ?>

    <?= $next_persoon ?> (<?= $next ?>)
    <input type='text' name="vervoeging"> 
    <input type='hidden' name="werkwoord" value="<?= $next; ?>">
    <input type='hidden' name="persoon" value="<?= $next_persoon ?>">
    <input type="submit" value="verstuur">

</form>

</body>
</html>